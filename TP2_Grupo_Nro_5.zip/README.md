# Trabajo Práctico N.° 2
## Programación III

Este repositorio contiene el código correspondiente al Primer Trabajo Práctico de la materia Programación III de la UTN-FRGP.

## Integrantes

- Jean Pierre Esquen
- Javier Torales
- María Olivia Hanczyc
- Máximo Tomás Canedo
- Ezequiel Alejandro Martínez

## Ejercicios a desarrollar

Cinco ejercicios, disponibles en el PDF.

## Contribuir

Sólo los integrantes del grupo pueden contribuir a este repositorio.

## Licencia

Este proyecto está bajo la Licencia MIT.
